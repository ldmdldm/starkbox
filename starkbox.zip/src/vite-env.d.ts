/// <reference types="vite/client" />

declare module '@/*' {
  const content: any;
  export default content;
}